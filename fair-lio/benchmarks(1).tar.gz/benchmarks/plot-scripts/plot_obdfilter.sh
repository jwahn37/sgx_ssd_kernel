#!/bin/bash


#########################################################################################
# ORNL OLCF-3 plot obdfilter I/O benchmark results script                               #
#                                                                                       #
#########################################################################################
# Originally by James Simmons <simmonsja@ornl.gov>	                                #
# Modified by Sarp Oral <oralhs@ornl.gov>, Jason Hill <hilljj@ornl.gov>                 #
# Oak Ridge Leadership Computing Facility                                               #
# National Center for Computational Science                                             #
# Oak Ridge National Laboratory                                                         #
#                                                                                       #
#                                                                                       #
# Copyright (C) 2009-2011 UT-Battelle, LLC                                              #
# This source code was developed under contract DE-AC05-00OR22725                       #
# and there is a non-exclusive license for use of this work by or                       #
# on behalf of the US Government.                                                       #
#                                                                                       #
# UT-Battelle, LLC AND THE GOVERNMENT MAKE NO REPRESENTATIONS AND                       #
# DISCLAIM ALL WARRANTIES, BOTH EXPRESSED AND IMPLIED. THERE ARE NO                     #
# EXPRESS OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A                     #
# PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT                          #
# INFRINGE ANY PATENT, COPYRIGHT, TRADEMARK, OR OTHER PROPRIETARY                       #
# RIGHTS, OR THAT THE SOFTWARE WILL ACCOMPLISH THE INTENDED RESULTS                     #
# OR THAT THE SOFTWARE OR ITS USE WILL NOT RESULT IN INJURY OR DAMAGE.                  #
# The user assumes responsibility for all liabilities, penalties, fines,                #
# claims, causes of action, and costs and expenses, caused by, resulting                #
# from or arising out of, in whole or in part the use, storage or disposal              #
# of the SOFTWARE.                                                                      #
#########################################################################################

#################################################################################################################
# NOTICE                                                                                                        #
#################################################################################################################
# This script requires:                                                                                         #
# 1) A pre-built gnuplot binary ready to execute.                                                               #
# 2) A pre-built ps2pdf binary to convert the gnuplot generated EPS plot files into PDF files                   #
#                                                                                                               #
# Usage:                                                                                                        #
# sh ./<this-script> <obdfilter-survey-data-file> <obdfilter-benchmark-cache-size> <appliancename> <diskname>   #
#                                                                                                               #
# Example:                                                                                                      #
# sh ./plot_obdfilter.sh obdfilter_survey_<timestamp>_<hostname>.summary acme-mk1 sas-10k	                  		#
#                                                                                                               #
# Please refer to the README file distributed with this script for further details.                             #
#################################################################################################################


#########################################################################################
# OFFEROR, MODIFY BELOW VARIABLES TO FIT TO YOUR TEST SYSTEM                            #
#########################################################################################
# There are no modifiable variables for this script!                                    #
#########################################################################################
# BEGIN OF MODIFIABLE VARIABLES AND PARAMETERS                                          #
#########################################################################################
#########################################################################################
# END OF MODIFIABLE VARIABLES AND PARAMETERS                                            #
#########################################################################################


#########################################################################
#               W A R N I N G !         W A R N I N G !                 #
#########################################################################
# DO NOT MODIFY ANYTHING BELOW !                                        #
# THERE ARE NO USER MODIFIABLE VARIABLES BELOW  !                       #
# ALL MODIFIABLE VARIABLES ARE LOCATED AT THE BEGINNING OF THIS FILE !  #
#########################################################################


#########################################################################
# DO NOT MODIFY ANYTHING BELOW !                                        #
#########################################################################



[ $# -ne 4 ] && {
	echo "This script requires four arguments, a obdfilter survey data file and cache size, platform, disk type"
	exit
}
[ -e $1 ] || {
	echo "The data file doesn't exist"
	exit
}
FILE=$1
CACHE=${2%GB}
device=$3
disk=$4

[ -e obdfilter_data[0-99] ] && rm obdfilter_data*
count=-1
max=0
j=0
while read data; do {
    data=$(echo $data | sed 's/SHORT/[  NAN, NAN\]/g')
    thread_count=$(echo $data | awk '{print $8}')
    row=$(echo $data | sed 's/\[[^]]*\]//g' | awk '{print$12"\t"$14"\t"$16"\t"}')
    [ -z "${thread_count##[0-9]*}" ] && {
        if [ $thread_count != $count ];then {
            touch obdfilter_data${thread_count}
            count=$thread_count
	    i=1
	} else {
	    i=$(expr $i + 1)
	} fi

  orig=$(sed -n "${i}p" obdfilter_data${thread_count})
	largest=$(echo ${row//.[0-9][0-9]/ } | tr " " "\n" | sort -g | tail -1);
	[ $max -lt $largest ] && max=$largest 
        if [ -z "$orig" ]; then {
            rsz=$(echo $data | awk '{print $10"\t"}')
            echo "$rsz$row" >> obdfilter_data${thread_count}
        } else {
            row="$orig $row"
            sed ''"$i"' c\ '"$row"'' -i obdfilter_data${thread_count}
        } fi
    }
} done < $FILE

for file in $(ls obdfilter_data*); do {
    obj=${file#obdfilter_data}

gnuplot << EOF
    set terminal postscript enhanced color 
    set output "${device}-${disk}-${CACHE}GB-${obj}-objs.eps"
    set title "Obdfilter-survey ${device} ${disk}, Cache ${CACHE} GB"
    set xlabel "number of threads"
    set ylabel "MB/s using $obj objs"
    set key left Left noreverse enhanced autotitles box
    set yrange [0:$((max+1000))]
    set ticslevel 0
    set style line 1 lt 1 lw 1 pt 1
    set style line 2 lt 2 lw 1 pt 1
    set style line 3 lt 3 lw 1 pt 1
    set style line 4 lt 1 lw 2 pt 4
    set style line 5 lt 2 lw 2 pt 4
    set style line 6 lt 3 lw 2 pt 4
    set style line 7 lt 1 lw 3 pt 9
    set style line 8 lt 2 lw 3 pt 9
    set style line 9 lt 3 lw 3 pt 9

    plot "obdfilter_data$obj" using 1:8  title "Writes for rsz 1024K" with lp ls 7, \
         "obdfilter_data$obj" using 1:10 title "Reads for rsz 1024K" with lp ls 9, \
         "obdfilter_data$obj" using 1:5  title "Writes for rsz 128K" with lp ls 4, \
         "obdfilter_data$obj" using 1:7  title "Reads for rsz 128K" with lp ls 6, \
         "obdfilter_data$obj" using 1:2  title "Writes for rsz 8K" with lp ls 1, \
         "obdfilter_data$obj" using 1:4  title "Reads for rsz 8K" with lp ls 3
EOF
} done

for i in *.eps; do ps2pdf $i; done
