
./fair-lio -q 1 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 /dev/sdb1 >> performance1.txt
sleep 31



./fair-lio -q 1 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 /dev/sdb1 >> performance1.txt
sleep 31


./fair-lio -q 1 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 /dev/sdb1 >> performance1.txt
sleep 31

./fair-lio -q 1 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 --random /dev/sdb1 >> performance1.txt
sleep 31



./fair-lio -q 1 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 --random /dev/sdb1 >> performance1.txt
sleep 31


./fair-lio -q 1 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 --random /dev/sdb1 >> performance1.txt
sleep 31


./fair-lio -q 1 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 -w --random /dev/sdb1 >> performance1.txt
sleep 31



./fair-lio -q 1 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 -w --random /dev/sdb1 >> performance1.txt
sleep 31


./fair-lio -q 1 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 -w --random /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 -w --random /dev/sdb1 >> performance1.txt
sleep 31


./fair-lio -q 1 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 -w /dev/sdb1 >> performance1.txt
sleep 31



./fair-lio -q 1 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 -w /dev/sdb1 >> performance1.txt
sleep 31


./fair-lio -q 1 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 2 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 4 -w /dev/sdb1 >> performance1.txt
sleep 31
./fair-lio -q 8 -w /dev/sdb1 >> performance1.txt
sleep 31

