echo -e "g\ng\nn\n\n\n\nw\n" | fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mount /dev/sdc1 /home/jinu/SSD
